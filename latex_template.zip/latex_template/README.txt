###[root]###
.\Main.tex
Todo-list

.\Appendix.tex
Appendix, obviously

.\references.bib
Referencer til kilder


###[root\aau]###
.\signatures.tex
Underskriftspladser for gruppemedlemmer

.\titlepages.tex
Navne p� gruppemedlemmer
Navne p� vejleder(e)
Abstract

.\preface.tex
Readers Guide
Terminology

###[root\setup]###
.\preamble.tex
Heavy setup stuff
Don't touch unless you know what you're doing

.\macros.tex
Required for AAU-stuff

.\variables.tex
For variables such as group name, paper name etc etc
Look inside to setup