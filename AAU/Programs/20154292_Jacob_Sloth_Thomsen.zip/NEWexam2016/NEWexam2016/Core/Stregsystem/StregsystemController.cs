﻿/*** Name: Jacob Sloth Thomsen
***  Student Number: 20154292
***/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NEWexam2016.Core.Stregsystem.EventHandling;
using NEWexam2016.Core.Exceptions;

namespace NEWexam2016.Core.Stregsystem
{
    class StregsystemController
    {
        private IStregsystem Stregsystem;
        private IStregsystemUI Ui;

        private Dictionary<string, Delegate> admincommands;

        private void FillAdminCommands()
        {
            admincommands.Add(":quit", new Action(Ui.Close));
            admincommands.Add(":q", new Action(Ui.Close));
            admincommands.Add(":activate", new Action<int>(Stregsystem.ActivateProduct));
            admincommands.Add(":deactivate", new Action<int>(Stregsystem.DeactivateProduct));
            admincommands.Add(":creditson", new Action<int>(Stregsystem.CreditsOn));
            admincommands.Add(":creditsoff", new Action<int>(Stregsystem.CreditsOff));
            admincommands.Add(":addcredits", new Func<User, decimal, InsertCashTransaction>(Stregsystem.AddCreditsToAccount));
        }

        public StregsystemController(IStregsystem stregsystem, IStregsystemUI stregsystemUI)
        {
            Stregsystem = stregsystem;
            Ui = stregsystemUI;

            Ui.CommandEntered += ParseCommand;

            admincommands = new Dictionary<string, Delegate>();
            FillAdminCommands();
        }

        public void ParseCommand(object sender, CommandEventArgs args)
        {
            string[] stringSpace = args.Command.Split();

            if (args.Command.StartsWith(":"))
            {
                try
                {
                    foreach (string key in admincommands.Keys)
                    {
                        if (key == stringSpace[0])
                        {
                            if (admincommands[key].GetType() == typeof(Action))
                            {
                                if (stringSpace.Length == 1)
                                {
                                    admincommands[key].DynamicInvoke();
                                }
                                else
                                {
                                    Ui.DisplayTooManyArgumentsError(args.Command);
                                }
                            }
                            else if (admincommands[key].GetType() == typeof(Action<int>))
                            {
                                if (stringSpace.Length == 2)
                                {
                                    admincommands[key].DynamicInvoke(Convert.ToInt32(stringSpace[1]));
                                }
                                else
                                {
                                    Ui.DisplayTooManyArgumentsError(args.Command);
                                }
                            }
                            else if (admincommands[key].GetType() == typeof(Func<User, decimal, InsertCashTransaction>))
                            {
                                if (stringSpace.Length == 3)
                                {
                                    admincommands[key].DynamicInvoke(Stregsystem.GetUserByUsername(stringSpace[1]), Convert.ToDecimal(stringSpace[2]));
                                }
                                else
                                {
                                    Ui.DisplayTooManyArgumentsError(args.Command);
                                }
                            }
                        }
                    }
                }
                catch (Exception e) { Ui.DisplayGeneralError(e.Message); } // Almighty

            }
            else
            {

                try
                {
                    User user = Stregsystem.GetUserByUsername(stringSpace[0]);

                    switch (stringSpace.Length)
                    {
                        case 1:
                            Ui.DisplayUserInfo(user);
                            break;

                        case 2:
                            Stregsystem.BuyProduct(user, Stregsystem.GetProductByID(Convert.ToInt32(stringSpace[1])));
                            break;

                        case 3:
                            for (int i = 0; i < Convert.ToInt32(stringSpace[2]); i++)
                            {
                                Stregsystem.BuyProduct(user, Stregsystem.GetProductByID(Convert.ToInt32(stringSpace[1])));
                            }
                            break;

                        default:
                            Ui.DisplayTooManyArgumentsError(args.Command);
                            break;
                    }
                }

                catch (UsernameDoesNotExistException) { Ui.DisplayUserNotFound(stringSpace[0]); }
                catch (NonActiveProductException) { Ui.DisplayProductNotActive(); }
                catch (InsufficientCreditsException) { Ui.DisplayInsufficientFunds(); }
                catch (Exception e) { Ui.DisplayGeneralError(e.Message); }
            }
        }
    }
}
