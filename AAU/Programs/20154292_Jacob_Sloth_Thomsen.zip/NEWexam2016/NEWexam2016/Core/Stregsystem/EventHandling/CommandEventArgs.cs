﻿/*** Name: Jacob Sloth Thomsen
***  Student Number: 20154292
***/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NEWexam2016.Core.Stregsystem;

namespace NEWexam2016.Core.Stregsystem.EventHandling
{
    class CommandEventArgs : EventArgs
    {
        public string Command;
    }
}
