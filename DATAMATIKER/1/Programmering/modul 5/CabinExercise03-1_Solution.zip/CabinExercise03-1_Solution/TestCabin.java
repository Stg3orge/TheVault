

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TestCabin.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TestCabin
{
    private Cabin cabin1;

    /**
     * Default constructor for test class TestCabin
     */
    public TestCabin()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        cabin1 = new Cabin(1, "Delfinvej", 9900, "L�kken");
        cabin1.setBuildingYear(1950);
        cabin1.setNoOfBeds(50);
        cabin1.setPricePrDay(1500);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
