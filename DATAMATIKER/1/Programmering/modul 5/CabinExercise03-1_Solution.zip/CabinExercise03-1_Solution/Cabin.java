
/**
 * Write a description of class Hytte here.
 * 
 * @author Kis Boisen Hansen, KNOL
 * @version (2009.02.09), 2017-09-20
 */
public class Cabin {
    private int id;
    private String address;
    private int postCode;
    private String city;
    private int buildingYear;
    private int noOfBeds;
    private int squareMeter;
    private double pricePrDay;
    private int noOfRooms;
    //mindstepris, ekstrasengpris
    

    /**
     * Constructor for objects of class Hytte
     */
    public Cabin(int id, String address, int postCode, String city) {
        this.id = id;
        this.address = address;
        this.postCode = postCode;
        this.city = city;
        squareMeter = 0;
        this.buildingYear = 0;
        pricePrDay = 0;
        noOfRooms = 0;
        noOfBeds = 0;
    }

    public void setPricePrDay(int pricePrDay){
        this.pricePrDay = pricePrDay;
    }
    
    public void setBuildingYear(int year){    
        this.buildingYear = year;
    }
    
    public void setNoOfBeds (int beds){
        noOfBeds = beds;
    }
    
    public void calculatePrice(int noOfPersons, int noOfDays){
        double price = noOfDays * pricePrDay;
        price = price + ekstraPrice(noOfPersons);
        price = price - discount(noOfDays);
        if(price > 200){
           System.out.println("Total rent is " + price);
        }
        else{
            System.out.println("Total rent is 200 kr.");
        }
        
    }
    
    private int ekstraPrice(int noOfPersons){
        int res = 0;
        if(noOfPersons > noOfBeds){
            int ekstraPersones = noOfPersons - noOfBeds;
            int ekstraPrice = ekstraPersones* 50;
            res = ekstraPrice;
        }
        return res;
    }
    
    private int discount(int days){  
        int discount = 0;
        if(buildingYear < 1950){
            discount = 200;
        }
        if( days > 7){
            discount = discount + 100;
        }
        return discount;
    }
    
}
