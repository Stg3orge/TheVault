import java.util.HashMap;
import java.util.Iterator;
import java.util.Collection;
import java.util.Set;
import java.util.Map;
/**
 * Iterator example code
 * 
 * @author Istvan Knoll
 * @version 2014-10-22
 */
public class IteratorExample {
    static {
        init();
    }
    
    private static HashMap<String, Integer> hm;
    
    protected static void init() {
        hm = new HashMap<>();
        hm.put("Three", 3);
        hm.put("Two", 2);
        hm.put("One", 1);
        hm.put("Minus one", -1);
    }
    
    public static void testKeyIterator() {
        Iterator<String> it = hm.keySet().iterator();
        while(it.hasNext()) {
            String key = it.next();
            Integer value = hm.get(key);
            System.out.println(key  +" = " + value);
        }
    }
    
    public static void testValueIterator() {
        Collection coll = hm.values();
        Iterator it = coll.iterator();
        while(it.hasNext()) {
            System.out.println(it.next());
        }
    }
    
    public static void testEntryIterator() {
        Set<Map.Entry<String, Integer>> entries = hm.entrySet();
        Iterator<Map.Entry<String, Integer>> it = entries.iterator();
        while(it.hasNext()) {
            Map.Entry<String, Integer> entry = it.next();
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + " = " + value);
        }
    }
    
    public static void testRemoveGood() {
        Iterator<Map.Entry<String, Integer>> it = hm.entrySet().iterator();
        while(it.hasNext()) {
            String key = it.next().getKey();
            if(key.equals("Two")) {
                it.remove(); // GOOD: Calling remove on the Iterator object
            }
            System.out.println(key + " = " + hm.get(key));
        }
        System.out.println("Removed Two = 2, printing the HashMap again\n");
        testEntryIterator(); 
    }
    
    public static void testRemoveBad() {
        try {
            Iterator<Map.Entry<String, Integer>> it = hm.entrySet().iterator();
            while(it.hasNext()) {
                String key = it.next().getKey();
                if(key.equals("Two")) {
                    hm.remove(key); // BAD: Calling remove on the HashMap object
                }
                
                System.out.println(key + " = " + hm.get(key));
            }
            System.out.println("Removed Two = 2, printing the HashMap again\n");
            testEntryIterator();
        }
        catch(Exception e) {
            e.printStackTrace();
            System.out.println(" *** Exception: " + e.getMessage() + " ***");
            init();
            System.out.println(" *** called init() to fix the test data ***");
        }
    }
}
