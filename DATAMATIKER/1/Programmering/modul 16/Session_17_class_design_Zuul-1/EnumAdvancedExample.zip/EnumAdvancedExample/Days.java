
/**
 * Enumeration class Days - an example enum with advanced functionality
 * 
 * @author Istvan Knoll
 * @version 2014-10-26, 2017-10-22
 */
public enum Days {
    // MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
    MONDAY(1, "Monday"), // This is how the constructor is called
    TUESDAY(2, "Tuesday"),  // arguments must match the parameter list in the constructor
    WEDNESDAY(3, "Wednesday"),
    THURSDAY(4, "Thursday"), 
    FRIDAY(5, "Friday"), 
    SATURDAY(6, "Saturday"), 
    SUNDAY(7, "Sunday");
    
    /**
     *  Constants that hold the values. 
     *  Values are assigned before we use the enum, we can't change them.
     */
    private final int day;
    private final String name;
    
    public static final int WEEK_LENGTH = 7;
    
    /**
     * Constructor, which tells Java how to assign values to the fields in the enum.
     * We DON'T call it when the enum is used in our program.
     * Instead, the constructor is called by the JVM once for each enum type, automatically 
     * and behind the scenes
     */
    Days(int day, String name) {
        this.day = day;
        this.name = name;
    }
    
    @Override
    public String toString() {
        return name + " is day number " + day + " in the " + WEEK_LENGTH + " days long week.";
    }
    
    /**
     * This method is created by the programmer and is not part of the standard enum interface. 
     * Instead, it is something, the programmer has decided would be useful.
     */
    public String getDayName(){
        return name;
    }
    
    /**
     * The same applies as for getDayName().
     */
    public int getDayNumber() {
        return day;
    }

	// Non-static stuff - a good use case?
	private String foo;
	public void setFoo(String foo){
		this.foo = foo;
	}
	public String getFoo() {
		return foo;
	}
}
