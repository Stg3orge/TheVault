
/**
 * Tests advanced features of Enum in Java
 * 
 * @author Istvan Knoll
 * @version 2014-10-26, 2017-10-22
 */
public class TestDays {
    public static void testValues() {
        explain(
        "Days[] days = Days.values();\n"+
        "for(int i = 0; i < days.length; i++) {\n" +
        "    System.out.println( days[i] );\n" +
        "}"
        );
        Days[] days = Days.values();
        for(int i = 0; i < days.length; i++) {
            System.out.println( days[i] );
        }
    }
 
    public static void testFields() {
        explain(
        "Days mon = Days.MONDAY;+\n"+
        "System.out.println(\"The name of the day is: \" + mon.getDayName());\n"+
        "System.out.println(\"The number of the day is: \" + mon.getDayNumber());\n");
        Days mon = Days.MONDAY;
        System.out.println("The name of the day is: " + mon.getDayName());
        System.out.println("The number of the day is: " + mon.getDayNumber());
    }
    
    public static void testBuiltInFunctions() {
        explain("Days tue = Days.TUESDAY;\n");
        Days tue = Days.TUESDAY;

        // name() --> MONDAY, TUESDAY, ...
        System.out.println("tue.name() returns: " + tue.name());

        // ordinal() --> 0, 1, ... 
        System.out.println("tue.ordinal() returns: " + tue.ordinal());

        // valueOf(String s) - e.g. "MONDAY" --> Days.MONDAY
        System.out.println("tue.valueOf(\"WEDNESDAY\") returns a Days instance, and is displayed by its toString(): " 
            + tue.valueOf("WEDNESDAY"));
        
        // Days.valueOf(class object, String with name of value) --> Days.XXXX
        // E.g. Days.valueOf(Days.class, "MONDAY") --> Days.MONdAY
        System.out.println("Days.valueOf(Days.class, \"FRIDAY\") returns a Days instance, displayed by its toString(): " 
            + Days.valueOf(Days.class, "FRIDAY"));
    }

    public static void testNonStatic() {  
        System.out.print('\u000C');//clear terminal in BlueJ (ONLY!)
        explain("Call this method twice in a row and observe the difference in output.");
        explain("Days mon = Days.MONDAY;");
        Days mon = Days.MONDAY;
        System.out.println("mon.getFoo(): " + mon.getFoo()); // default value is printed
        explain("\nmon.setFoo(\"Foo!\");"); 
        mon.setFoo("Foo!"); // foo is not final, it can be set
        System.out.println("mon.getFoo(): " + mon.getFoo()); // now getFoo returns the previously set value
        
        explain("\nmon.setFoo(\"Bar.\");"); 
        mon.setFoo("Bar."); // foo is not final, it can be set
        System.out.println("mon.getFoo(): " + mon.getFoo()); // now getFoo returns the previously set value
        //Days d = new Days(9, "FunnyDay"); // Enums can't be instantiated
    }
    private static void explain(String s) {
        System.out.println(s);
    }
}
