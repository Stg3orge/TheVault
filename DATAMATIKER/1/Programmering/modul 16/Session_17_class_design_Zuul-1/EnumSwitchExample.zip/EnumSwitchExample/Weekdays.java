
/**
 * Write a description of class Weekdays here.
 * 
 * @author Istvan Knoll
 * @version 2014-10-23
 */
public enum Weekdays {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
}
