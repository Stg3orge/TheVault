
/**
 * A demo of basic Enum and switch
 *
 * @author Istvan Knoll
 * @version 2014-10-23
 */
public class EnumSwitchExample {
    public static void test(Weekdays day) {
        //Weekdays day = Weekdays.SUNDAY;
        
        switch(day) {
            case SATURDAY:
            case SUNDAY:
                System.out.println("It's weekend");
                break;
            case MONDAY:
                System.out.println("It's Monday");
            default:
                System.out.println("It's a working day");
                break;
        }
    }
}
