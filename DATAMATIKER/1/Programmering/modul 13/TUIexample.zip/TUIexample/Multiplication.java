
/**
 * Write a description of class Multiplication here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Multiplication {
    public void table() {
        String s = "";
        for(int i = -1; i <= 10 ; i++) {
            for(int j = 0 ; j <= 10; j++) {
                if( i == -1) {
                    s = j == 0 ? "\t|" : "\t" + j ;
                }
                else if(i == 0) {
                    s = "________";
                }
                else {
                    s = j == 0 ? "\t" + i + "|" : "\t" + (i * j);
                }
                System.out.print(s);
            }
            System.out.println();
        }
    }
}
