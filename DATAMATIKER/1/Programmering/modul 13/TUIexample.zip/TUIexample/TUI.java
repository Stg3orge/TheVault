import java.util.Scanner;
/**
 * Write a description of class TUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TUI {
    public void start() {
        Scanner s = new Scanner(System.in);
        boolean goOn = true;
        while(goOn) {
            System.out.print("Question: ");
            String answer = s.nextLine();
            if(answer.equals("bye")) {
                goOn = false;
            }
            else {
                System.out.println("Answer " + answer);
            }
        }
        System.out.println("so long...");
    }
    
    public static void main(String... a) {
        new TUI().start();
    }
}
