import java.util.*;

public class Maps {
    public void f() {
        HashMap<String, String> map = new HashMap<>();
        
        map.put("joe    ", "banana");
        map.put("cotton  ", "eyed joe");
        map.put("bud   ", "banana");
        map.put("arnold  ", "a sixpack");
        map.put("arnold  ", "Terminator");
        
       
        for(String currKey : map.keySet()) {
            System.out.println(currKey + " : \t" + map.get(currKey));
        }
    }
}