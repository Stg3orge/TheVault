import java.util.*;

public class Sets {
    public void testSets() {
        HashSet<String> hs = new HashSet<>();
        hs.add("one");
        hs.add("joe");
        hs.add("3");
        
        for(String s : hs) {
            System.out.print(s + ", ");
        }
        System.out.println();
        
        Iterator<String> it = hs.iterator();
        while(it.hasNext()) {
            String s = it.next();
            System.out.print(s + ", ");
        }
        System.out.println();
        
        String s;
        for(Iterator<String> it2 = hs.iterator(); it2.hasNext(); ) {
            s = it2.next();
            System.out.print(s + ", ");
        }
        System.out.println();
    }
}