import java.util.*;

public class MappedBaby {
    public void teachMe() {
        boolean goOn = true;
        Scanner scanner = new Scanner(System.in);
        HashMap<String, String> wisdoms = new HashMap<>();
        
        while(goOn) {
            System.out.println("Teach me, master!");
            String input = scanner.nextLine();
            if(input.toLowerCase().contains("bye")) {
                goOn = false;
            }
            else {
                String[] inputTokens = input.split(" ");
                if(inputTokens.length >= 2) {
                    wisdoms.put(inputTokens[0], inputTokens[inputTokens.length - 1]);
                    System.out.println("   Thank you for your wisdom, master!");
                }
                else {
                    System.out.println("   This wisdom was too short, I don't understand!");
                }
            }
            
           
        }
        System.out.println("\nThis is what I have learned today:");
        for(String currKey : wisdoms.keySet()) {
            System.out.println(currKey + " means " + wisdoms.get(currKey));
        }
    }
}