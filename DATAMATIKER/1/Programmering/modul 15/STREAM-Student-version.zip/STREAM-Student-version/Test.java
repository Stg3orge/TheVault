public class Test {
    private Test() {}
    
    public static void main (String... args) {
        IDate.main(null);
    }
}