package ctr;

public class NoGroceryListException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoGroceryListException(String string) {
		super(string);
	}

}
