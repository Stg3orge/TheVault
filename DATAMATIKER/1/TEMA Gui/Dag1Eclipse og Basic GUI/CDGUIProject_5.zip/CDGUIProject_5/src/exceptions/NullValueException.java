package exceptions;

public class NullValueException extends Exception {
	public NullValueException(String fieldName) {
		super("You must specify a value for " + fieldName + ".");
	}
}
