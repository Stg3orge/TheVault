package exceptions;

public class RecordExistsException extends Exception {

	public RecordExistsException(String recordName, String value) {
		super("The " + recordName + " entry '" + value + "' already exists.");
	}

}
