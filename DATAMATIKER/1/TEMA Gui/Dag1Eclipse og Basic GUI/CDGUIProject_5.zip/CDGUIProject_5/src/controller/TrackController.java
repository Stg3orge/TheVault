package controller;

import java.util.ArrayList;

import model.AbstractContainer;
import model.CD;
import model.CDContainer;
import model.Track;
import model.TrackContainer;
import exceptions.NullValueException;
import exceptions.RecordExistsException;

public class TrackController extends AbstractRecordController<Track> {

	private TrackContainer tracks = TrackContainer.getInstance();
	
	@Override
	public Track create(Track o) throws NullValueException, RecordExistsException {
		Track track = super.create(o);
		track.setCD(o.getCD());		
		track = update(track, track);
		return track;
	}

	@Override
	public Track update(Track old, Track fresh) throws NullValueException {
		Track track = tracks.find(old.getId());
		track.setName(fresh.getName());
		track.setPlayTime(fresh.getPlayTime());
		if(fresh.getCD() != null) {
			CD cd = CDContainer.getInstance().find(fresh.getCD().getId());
			track.setCD(cd);
		}
		return (Track)track.deepClone();
	}

	@Override
	protected AbstractContainer<Track> getContainer() {
		return tracks;
	}

	public ArrayList<Track> findAllOn(CD cd) throws IllegalArgumentException, NullValueException {
		ArrayList<Track> result = new ArrayList<>(3);
		Track currentTrack = null;
		for(int i = 0 ; i < cd.getTracks().size(); i++) {
			currentTrack = find(cd.getTracks().get(i).getId());
			if(currentTrack != null)
				result.add(currentTrack);
		}
		return result;
	}
	
	@Override
	public Track delete(int id) throws NullValueException {
		Track deleted = TrackContainer.getInstance().find(id);
		Track track = super.delete(id);
		
		ArrayList<CD> cds = CDContainer.getInstance().getAll();
		for(CD cd:cds ) {
			cd.removeTrack(deleted);
		} 
		
		return track;
	}

}
