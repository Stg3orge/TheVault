package controller;

import java.util.ArrayList;
import model.AbstractContainer;
import model.Artist;
import model.ArtistContainer;
import model.CD;
import model.CDContainer;
import exceptions.NullValueException;

public class ArtistController extends AbstractRecordController<Artist>{

	private AbstractContainer<Artist> artists;;
	
	public ArtistController() {
		this.artists = ArtistContainer.getInstance();
	}

	@Override
	public Artist update(Artist old, Artist fresh) throws NullValueException  {
		Artist artist = artists.find(old.getId());
		artist.setName(fresh.getName());
		return artist.clone();
	}

	@Override
	protected AbstractContainer<Artist> getContainer() {
		return artists;
	}
	
	@Override
	public Artist delete(int id) throws NullValueException {
		Artist deleted = ArtistContainer.getInstance().find(id); // this is the real object from the model layer!
		Artist artist = super.delete(id);
		
		// let's not try to remove an artist from CDs that couldn't be found in the container
		if(artist == null)
			return null;
		
		// remove links from CD
		ArrayList<CD> cds = CDContainer.getInstance().getAll();
		boolean found = false;
		Artist a = null;
		for(CD cd : cds) {
			found = false;
			for(int i = 0; !found && i < cd.getArtists().size(); i++) {
				a = cd.getArtists().get(i);
				found = a.equals(deleted);
			}
			if(found)
				cd.removeArtist(deleted);
		}
		return artist; // still returns a reference to a clone of the original record!
	}
}
