package controller;

import java.util.HashMap;

import model.Artist;
import model.ArtistContainer;
import model.CD;
import model.Track;
import model.TrackContainer;
import exceptions.NullValueException;
import exceptions.RecordExistsException;

/**
 * Used both to insert test data and to test the creation of test data
 * 
 *
 */
public class Demo {
	private static HashMap<String, Artist> artists = new HashMap<>();
	private static HashMap<String, CD> cds = new HashMap<>();
	private static HashMap<String, Track> tracks = new HashMap<>();
	
	public static void main(String[] args) throws NullValueException, RecordExistsException {
		insertArtistDemoData();
		insertTrackDemoData();
		insertCDDemoData();
		p(artists);
		p(tracks);
		p(cds);
	}
	
	private static void p(@SuppressWarnings("rawtypes") HashMap x) {
		for(Object o : x.entrySet()) {
			String s = o.toString() + "\n";
			System.out.println(s);
		}		
	}
	private static void rem(Artist a){
		artists.put(a.getName(), a);
	}
	private static void rem(CD cd) {
		cds.put(cd.getName(), cd);
	}
	private static void rem(Track t) {
		tracks.put(t.getName(), t);
	}
	public static void insertArtistDemoData() throws NullValueException, RecordExistsException {
		ArtistController ac = new ArtistController();
		Artist a = new Artist();
		a.setName("Steve Jobs");
		a = ac.create(a);
		rem(a);
		
		a = new Artist();
		a.setName("Steve Ballmer");
		a = ac.create(a);
		rem(a);
		
		a = new Artist();
		a.setName("Bill Gates");
		a = ac.create(a);
		rem(a);
		
		a = new Artist();
		a.setName("Linus Torvalds");
		a = ac.create(a);
		rem(a);
		
		a = new Artist();
		a.setName("Richard Stallman");
		a = ac.create(a);
		rem(a);
	}
	
	public static void insertCDDemoData() throws NullValueException, RecordExistsException {
		CDController cdc = new CDController();

		CD cd = new CD();
		cd.setTitle("Best of Ballmer Mega Mix");
		cd.setYear(2012);
		cd.addArtist(ArtistContainer.getInstance().find(artists.get("Steve Ballmer")));
		cd.addArtist(ArtistContainer.getInstance().find(artists.get("Bill Gates")));
		cd.addTrack(TrackContainer.getInstance().find(tracks.get("Monkey Dance")));
		cd.addTrack(TrackContainer.getInstance().find(tracks.get("Developers")));
		cd.addTrack(TrackContainer.getInstance().find(tracks.get("Singing and Dancing")));
		cd = cdc.create(cd);
		rem(cd);
		
		cd = new CD();
		cd.setTitle("Macbook Air Single");
		cd.setYear(2008);
		cd.addArtist(ArtistContainer.getInstance().find(artists.get("Steve Jobs")));
		cd.addTrack(TrackContainer.getInstance().find(tracks.get("Macbook Air Song")));
		cd = cdc.create(cd);
		rem(cd);
		
		cd = new CD();
		cd.setTitle("Open Source Parade");
		cd.setYear(2012);
		cd.addArtist(ArtistContainer.getInstance().find(artists.get("Linus Torvalds")));
		cd.addArtist(ArtistContainer.getInstance().find(artists.get("Richard Stallman")));
		cd.addTrack(TrackContainer.getInstance().find(tracks.get("Epic Linux Community Song")));
		cd.addTrack(TrackContainer.getInstance().find(tracks.get("Free Software Song")));
		cd = cdc.create(cd);
		rem(cd);
	}

	public static void insertTrackDemoData() throws NullValueException, RecordExistsException {
		TrackController tc = new TrackController();
		
		Track t = new Track();
		t.setName("Free Software Song");
		t.setPlayTime(123);
		t = tc.create(t);
		rem(t);
		
		t = new Track();
		t.setName("Epic Linux Community Song");
		t.setPlayTime(234);
		t = tc.create(t);
		rem(t);
		
		t = new Track();
		t.setName("Macbook Air Song");
		t.setPlayTime(400);
		t = tc.create(t);
		rem(t);
		
		t = new Track();
		t.setName("Singing and Dancing");
		t.setPlayTime(32);
		t = tc.create(t);
		rem(t);
		
		t = new Track();
		t.setName("Developers");
		t.setPlayTime(59);
		t = tc.create(t);
		rem(t);
		
		t = new Track();
		t.setName("Monkey Dance");
		t.setPlayTime(560);
		t = tc.create(t);
		rem(t);
		
	}
	
 
}
