package controller;

import model.AbstractContainer;
import model.Artist;
import model.ArtistContainer;
import model.CD;
import model.CDContainer;
import model.Track;
import model.TrackContainer;
import exceptions.NullValueException;
import exceptions.RecordExistsException;

public class CDController extends AbstractRecordController<CD> {
	private CDContainer cds;
	
	public CDController() {
		this.cds = CDContainer.getInstance();
	}
	
	@Override
	public CD delete(int id) throws NullValueException {
		CD cd = super.delete(id);
		TrackController tc = new TrackController();
		for(Track track : cd.getTracks()){
			tc.delete(track.getId());
		}
		return cd;
	}
	
	@Override
	public CD create(CD cd) throws NullValueException, RecordExistsException {
		CD newCd = super.create(cd);
		return update(newCd, cd); 
	}

	@Override
	public CD update(CD old, CD fresh) throws NullValueException  {
		CD cd = cds.find(old.getId());
		cd.setTitle(fresh.getTitle());
		cd.setYear(fresh.getYear());
		
		cd.getArtists().clear();
		cd.getTracks().clear();
		Artist a = null;
		AbstractContainer<Artist> ac = ArtistContainer.getInstance();
		for(int i = 0; i < fresh.getArtists().size(); i++) {
			a = ac.find(fresh.getArtists().get(i).getId());
			cd.addArtist(a);
		}
		
		Track t = null;
		TrackContainer tc = TrackContainer.getInstance();
		for(int i = 0; i < fresh.getTracks().size(); i++){
			t = tc.find(fresh.getTracks().get(i).getId());
			cd.addTrack(t);
		}
		
		return (CD)cd.deepClone();
	}

	@Override
	protected AbstractContainer<CD> getContainer() {
		return cds;
	}

}
