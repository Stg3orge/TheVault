package controller;

import java.util.ArrayList;
import model.AbstractContainer;
import model.AbstractModelClass;
import exceptions.NullValueException;
import exceptions.RecordExistsException;

public abstract class AbstractRecordController <T extends AbstractModelClass>{
	public abstract T update(T old, T fresh) throws NullValueException;
	protected abstract AbstractContainer<T> getContainer(); 

	public AbstractRecordController() {
		super();
	}
	
	@SuppressWarnings("unchecked")
	public T find(int id) throws IllegalArgumentException, NullValueException {
		AbstractModelClass record = getContainer().find(id); 
		if(record != null)
			return (T)record.deepClone();
		return null;
	}
	
	public T delete (int id) throws NullValueException {
		return getContainer().delete(id);
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<T> getAll() {
		ArrayList<T> result = new ArrayList<>();
		T t = null;
		for(int i = 0 ; i < getContainer().getAll().size(); i++) {
			t = (T)getContainer().getAll().get(i).deepClone();
			result.add(t);
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	public T create(T t) throws NullValueException, RecordExistsException {
		T tt = (T)t.deepClone();
		getContainer().add(tt);
		return (T)tt.deepClone();
	}

	public String getControlledModelName() {
		return getContainer().getRecordName();
	}
	
	@Override
	public String toString() {
		ArrayList<? extends AbstractModelClass> records = this.getAll();
		StringBuilder sb = new StringBuilder();
		for(int i = 0 ; i < records.size(); i++) {
			sb.append(records.get(i).toString());
			sb.append(i < records.size() - 1 ? "; " : "");
		}
		return sb.toString();
	}

}
