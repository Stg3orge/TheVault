package controller;

import gui.FileChooser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import model.AbstractContainer;
import model.AbstractModelClass;
import model.ArtistContainer;
import model.CDContainer;
import model.TrackContainer;


public class MainController  {
	private static MainController instance;
	private ArrayList<AbstractContainer<? extends AbstractModelClass>> containers = new ArrayList<>();
	
	private MainController() {
		// make serialization possible by saving this.containers
		this.containers.add(ArtistContainer.getInstance());
		this.containers.add(CDContainer.getInstance());
		this.containers.add(TrackContainer.getInstance());
	}
	
	public static MainController getInstance(){
		if(instance == null)
			instance = new MainController();
		return instance;
	}
	
	public void exit(boolean save) {
		if(save) {
			save(FileChooser.show(null));
		}
		System.exit(0);
	}
	
	public boolean save(File f) {
		if(f == null)
			return false;
		if(!f.getName().toLowerCase().endsWith(".cdx")) {
			f = new File(f.getPath() + ".cdx");
		}
		FileOutputStream f_out;
		try {
			// Write to disk with FileOutputStream
			f_out = new FileOutputStream(f);

			// Write object with ObjectOutputStream
			ObjectOutputStream obj_out = new ObjectOutputStream (f_out);

			// Write object out to disk
			obj_out.writeObject ( this.containers );
			
			f_out.close();
			
			return true;
		} 
		catch (IOException e) {
			return false;
		}

	}

	@SuppressWarnings("unchecked")
	public boolean load(File f) { 
		try {
			// Read from disk using FileInputStream
			FileInputStream f_in = new FileInputStream(f);

			// Read object using ObjectInputStream
			ObjectInputStream obj_in = new ObjectInputStream (f_in);

			// Read an object
			Object obj = obj_in.readObject();

			obj_in.close();
			
			this.containers = (ArrayList<AbstractContainer<? extends AbstractModelClass>>)obj;
			
			for(AbstractContainer<? extends AbstractModelClass> container : this.containers) {
				if(container instanceof ArtistContainer) 
					ArtistContainer.setInstance((ArtistContainer) container);
				else if(container instanceof CDContainer)
					CDContainer.setInstance((CDContainer) container);
				else if(container instanceof TrackContainer)
					TrackContainer.setInstance((TrackContainer) container);
			}

			return true;
		} 
		catch (Exception e) {
			return false;
		}
	
	}
	
	
}
