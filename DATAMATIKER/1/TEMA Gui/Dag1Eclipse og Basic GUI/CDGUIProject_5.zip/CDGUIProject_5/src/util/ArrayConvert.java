package util;

import java.util.List;


public class ArrayConvert {
	public static int[] toIntArray(List<Integer> list) {
		if(list == null)
			return null;
		int [] result = new int[list.size()];
		for(int i = 0 ; i < list.size(); i++) {
			result[i] = list.get(i);
		}
		return result;
	}
}
