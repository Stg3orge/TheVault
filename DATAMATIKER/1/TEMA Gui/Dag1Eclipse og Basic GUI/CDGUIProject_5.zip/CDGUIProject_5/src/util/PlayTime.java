package util;

public class PlayTime {
	public static String formatDuration(int seconds) {
		int minutes = seconds / 60;
		seconds = seconds % 60;
		String res = String.format("%02d",  minutes);
		res += ":" + String.format("%02d", seconds);
		return res;
	}

}
