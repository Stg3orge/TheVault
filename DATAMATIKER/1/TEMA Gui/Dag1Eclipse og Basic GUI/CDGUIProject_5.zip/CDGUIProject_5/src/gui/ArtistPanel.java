package gui;

import javax.swing.JOptionPane;
import model.Artist;
import controller.ArtistController;
import controller.Demo;
import exceptions.NullValueException;
import exceptions.RecordExistsException;

public  class ArtistPanel extends AbstractRecordPanel {
	private ATableModel tableModel; 

	/**
	 * Create the panel.
	 */
	public ArtistPanel() {
	}


	// methods
	@Override
	void actionNew(){
		String name = JOptionPane.showInputDialog(this, "Name of the new artist?");
		if (name == null)
			return;
		try {
			Artist artist = new Artist();
			artist.setName(name);
			this.getRecordController().create(artist);
			super.refreshData();
		} catch (Exception  e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Input error", JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	void actionEdit() {
		Artist currentArtist = (Artist)getSelectedRecord();
		if(currentArtist == null)
			return;

		String newName = JOptionPane.showInputDialog(this, "You can now change the artist's name", currentArtist.getName());
		if(newName == null)
			return;
		try {
			Artist fresh = currentArtist.deepClone();
			fresh.setName(newName);
			this.getRecordController().update(currentArtist, fresh);
		} catch (NullValueException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Input error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		super.refreshAllData();
	}


	@Override
	ATableModel getTableModel() {
		if(this.tableModel == null){
			this.tableModel = new ArtistTableModel();
			super.refreshData();
		}
		return this.tableModel;
	}

	@Override
	void doInsertTestData() throws NullValueException, RecordExistsException{
		Demo.insertArtistDemoData();
	}
	
	@Override
	protected ArtistController getRecordController() {
		return new ArtistController();
	}

	@Override
	void doInit() {}


}
