package gui;

import util.PlayTime;
import model.Track;

public class TrackTableModel extends ATableModel {

	public TrackTableModel() {
		super(new String[]{"Track title", "Duration"});
	}
	
	private TrackTableModel(String[] columnNames) {
		super(columnNames);
	}

	@Override
	public String getValueAt(int row, int col) {
		if(super.getModelAt(row) == null)
			return null;
		Track track = (Track)getModelAt(row);
		switch(col) {
			case 0:
				return track.getName();
			case 1:
				return PlayTime.formatDuration(track.getPlayTime());
		}
		return null;
	}

}
