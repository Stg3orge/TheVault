package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import model.CD;
import controller.MainController;

public class MainWindow extends JFrame {
	private MainController controller = MainController.getInstance();
	private ArtistPanel panel_artists;
	private CDPanel panel_cds;
	private TrackPanel panel_tracks;
	private JPanel contentPane;
	
	private CD selectedCd;

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		
		setFont(new Font("Dialog", Font.BOLD, 12));
		setTitle("My CD Collection");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 450);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		mnFile.setMnemonic('F');
		menuBar.add(mnFile);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setMnemonic('x');
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				actionExit();
			}
		});
		
		JMenuItem mntmSave = new JMenuItem("Save");
		mntmSave.setMnemonic('S');
		mntmSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				actionSave();
			}
		});
		mnFile.add(mntmSave);
		
		JMenuItem mntmInsertTestData = new JMenuItem("Insert test data");
		mntmInsertTestData.setMnemonic('t');
		mntmInsertTestData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				actionInsertTestData();
			}
		});
		
		JMenuItem mntmLoad = new JMenuItem("Load");
		mntmLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actionLoad();
			}
		});
		mntmLoad.setMnemonic('L');
		mnFile.add(mntmLoad);
		
		mnFile.add(mntmInsertTestData);
		mnFile.add(mntmExit);
		
		JMenu mnHelp = new JMenu("Help");
		mnHelp.setMnemonic('H');
		menuBar.add(mnHelp);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				actionAbout();
			}
		});
		mntmAbout.setMnemonic('A');
		mnHelp.add(mntmAbout);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(5, 5));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane, BorderLayout.CENTER);
		 
		// tabbed panel
		JPanel panel_collection = new JPanel();
		tabbedPane.addTab("Collection", null, panel_collection, null);
		panel_collection.setLayout(new GridLayout(1, 2, 5, 5));
		
		panel_cds = new CDPanel(); // handcoded class name
		panel_collection.add(panel_cds);
		
		panel_tracks = new TrackPanel();
		panel_tracks.setBackground(Color.GREEN);
		panel_collection.add(panel_tracks);
		this.
		
		// panel_artists: artists
		panel_artists = new ArtistPanel(); 
		tabbedPane.addTab("Artists", null, panel_artists, null);
	}
	
	public CD getSelectedCd() {
		return selectedCd;
	}


	public void setSelectedCd(CD selectedCd) {
		this.selectedCd = selectedCd;
	}
	
	
	// handcoded...
	private void actionExit() {
		int answer = JOptionPane.showConfirmDialog(this, "Would you like to save your work before exiting?", "Exit", JOptionPane.YES_NO_CANCEL_OPTION);
		if(answer == JOptionPane.OK_OPTION)
			controller.exit(true);
		else if (answer == JOptionPane.NO_OPTION)
			controller.exit(false);
		//else JOptionPane.CANCEL_OPTION
			// Do nothing.
	}
	
	private void actionAbout() {
		JOptionPane.showMessageDialog(this, "Developed at UCN (2013)", "About", JOptionPane.OK_OPTION);
	}
	
	private void actionSave() {
		File f = FileChooser.show(this);
		if(f == null)
			return;
		boolean result = controller.save(f);
		if(!result)
			JOptionPane.showMessageDialog(this, "Sorry, couldn't save your project to " + f.getPath(), "Error while saving", JOptionPane.ERROR_MESSAGE);
		this.refreshAllData();
	}
	
	private void actionLoad() {
		File f = FileChooser.show(this);
		if(f == null)
			return;
		boolean result = controller.load(f);
		if(!result)
			JOptionPane.showMessageDialog(this, "My aplogies, I couldn't load the file " + f.getPath(), "Error while loading", JOptionPane.ERROR_MESSAGE);
		this.refreshAllData();
	}
	
	
	private void actionInsertTestData(){
		// These data are for demonstration purposes only. This method serves solely this purpose.
		this.panel_artists.actionInsertTestData();
		this.panel_tracks.actionInsertTestData();
		this.panel_tracks.getTableModel().setModel(null);
		this.panel_cds.actionInsertTestData();
	}

	public TrackPanel getPanel_tracks() {
		return panel_tracks;
	}

	public void refreshAllData() {
		this.panel_tracks.refreshData();
		this.panel_cds.refreshData();
		this.panel_artists.refreshData();
	}
	

}
