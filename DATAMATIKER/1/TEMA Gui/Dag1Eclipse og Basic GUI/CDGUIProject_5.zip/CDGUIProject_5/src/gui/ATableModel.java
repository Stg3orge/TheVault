package gui;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import model.AbstractModelClass;

public abstract class ATableModel extends AbstractTableModel {

	private ArrayList<? extends AbstractModelClass> model;
	private String[] columnNames = new String[0];

	ATableModel(String[] columnNames) {
		super();
		this.columnNames = columnNames;
	}
	
	/**
	 * @param records
	 */
	protected void setModel(ArrayList<? extends AbstractModelClass> records) {
		this.model = records;
		fireTableDataChanged(); // Fort�l tabellen, at data har �ndret sig!
	}
	

	protected AbstractModelClass getModelAt(int index) {
		if(model == null || index < 0 || index >= this.model.size()) {
			return null;
		}
		return model.get(index);
	}

	@Override
	public boolean isCellEditable(int row, int col) {
		return false;
	}

	@Override
	public String getColumnName(int col) {
		return this.columnNames[col];
	}

	@Override
	public int getColumnCount() {
		return this.columnNames.length;
	}

	@Override
	public int getRowCount() {
		if(model != null)
			return model.size();
		return 0;
	}

	@Override
	public abstract String getValueAt(int row, int col) ;

}