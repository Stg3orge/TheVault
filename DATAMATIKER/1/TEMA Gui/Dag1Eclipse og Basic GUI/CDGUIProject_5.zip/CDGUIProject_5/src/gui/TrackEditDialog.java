package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.InputVerifier;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import model.Track;

public class TrackEditDialog extends JDialog {

	private Track track;	
	
	private final JPanel contentPanel = new JPanel();
	private JTextField textTrackTitle;
	private JTextField textMinutes;
	private JTextField textSeconds;
	private JLabel labelErrorMessage;


	private class IntegerInputVerifier extends InputVerifier {

		@Override
		public boolean verify(JComponent arg0) {
			String input = ((JTextField)arg0).getText();
			if(input.trim().isEmpty())
				return true;
			try{
				new Integer(input.trim());
				displayIntegerFormattingError(false);
				return true;
			}
			catch(NumberFormatException e){
				displayIntegerFormattingError(true);
				return false;
			}
		}
	}
	
	
	/**
	 * Create the dialog.
	 */
	protected TrackEditDialog() {
		setFont(new Font("Dialog", Font.BOLD, 12));
		setTitle("Create new Track");
		setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setAlwaysOnTop(true);
		setModal(true);
		setBounds(100, 100, 375, 145);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Track title:");
			lblNewLabel.setBounds(5, 8, 82, 14);
			contentPanel.add(lblNewLabel);
		}
		{
			textTrackTitle = new JTextField();
			textTrackTitle.setBounds(110, 5, 239, 20);
			contentPanel.add(textTrackTitle);
			textTrackTitle.setColumns(10);
		}
		{
			JLabel lblNewLabel_1 = new JLabel("Duration (mm:ss):");
			lblNewLabel_1.setBounds(5, 30, 95, 14);
			contentPanel.add(lblNewLabel_1);
		}
		
		textMinutes = new JTextField();
		textMinutes.setToolTipText("Specify how many minutes the Track plays");
		textMinutes.setBounds(110, 27, 53, 20);
		contentPanel.add(textMinutes);
		textMinutes.setColumns(10);
		textMinutes.setInputVerifier(new IntegerInputVerifier());
		
		JLabel label = new JLabel(":");
		label.setBounds(165, 30, 4, 14);
		contentPanel.add(label);
		
		textSeconds = new JTextField();
		textSeconds.setToolTipText("Specify how many seconds the Track plays");
		textSeconds.setColumns(10);
		textSeconds.setBounds(173, 27, 53, 20);
		textSeconds.setInputVerifier(new IntegerInputVerifier());
		contentPanel.add(textSeconds);
		{
			labelErrorMessage = new JLabel("");
			labelErrorMessage.setBounds(233, 30, 116, 14);
			contentPanel.add(labelErrorMessage);
		}
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(271, 109, 5, 5);
		contentPanel.add(tabbedPane);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(track == null)
							track = new Track();
						setVisible(false);
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
	private void displayIntegerFormattingError(boolean error) {
		String text = "";
		if(error)
			text ="Only 0..9 allowed!";			
		this.labelErrorMessage.setText(text);
	}
	
	public void setTrack(Track track) {
		this.track = track;
		this.setTitle("Edit Track properties");
		if(track != null) {
			this.textMinutes.setText(new Integer(track.getPlayTime() / 60).toString());
			this.textSeconds.setText(new Integer(track.getPlayTime() % 60).toString());
			this.textTrackTitle.setText(track.getName());
		}
	}
	
	public Track getTrack() {
		if(!this.validateDurations()) {
			JOptionPane.showMessageDialog(this, "You may only use numbers to specify the duration\nof a track!", "Input error", JOptionPane.ERROR_MESSAGE);
			return null;
		}
		if(this.track == null) {
			return null;
		}
		String trackName = this.textTrackTitle.getText().trim();
		this.track.setName(trackName);
		int duration = new Integer(this.textSeconds.getText().trim().equals("") ?
				"0":
				this.textSeconds.getText().trim());
		duration+=     new Integer(this.textMinutes.getText().trim().equals("") ?
				"0":
				this.textMinutes.getText().trim())
			.intValue()
			*60;
		this.track.setPlayTime(duration);
		return this.track;
	}
	
	private boolean validateDurations() {
		InputVerifier iv = this.new IntegerInputVerifier();
		return (iv.verify(this.textMinutes) && iv.verify(this.textSeconds));
	}
	
}
