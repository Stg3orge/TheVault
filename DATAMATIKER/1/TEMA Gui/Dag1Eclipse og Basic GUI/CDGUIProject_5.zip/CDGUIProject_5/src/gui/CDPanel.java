package gui;

import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import model.AbstractModelClass;
import model.CD;
import controller.CDController;
import controller.Demo;
import exceptions.NullValueException;
import exceptions.RecordExistsException;

public class CDPanel extends AbstractRecordPanel {
	public CDPanel() {
	}
	private CDTableModel tableModel;
	

	@Override
	void actionEdit() {
		CD cd = (CD)this.getSelectedRecord();
		if(cd == null) {
			JOptionPane.showMessageDialog(this, "Select a CD to edit!", "No CD selected", JOptionPane.WARNING_MESSAGE);
			return;
		}
		 this.showCDDialog(cd);
	}

	@Override
	void doInsertTestData() throws NullValueException, RecordExistsException {
		Demo.insertCDDemoData();
	}

	@Override
	void actionNew() {
		this.showCDDialog(null);
	}

	@Override
	ATableModel getTableModel() {
		if(this.tableModel == null) {
			this.tableModel = new CDTableModel();
		}
		return this.tableModel;
	}

	@Override
	CDController getRecordController() {
		return new CDController();
	}
	
	@Override
	void doInit() {
		// Detect when a new row (= CD) is selected, s.t. the relevant tracks can be shown in the TrackPanel
		super.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				actionCDSelected();				
			}
		});
	}
	
	private void actionCDSelected() {
		MainWindow mainWindow = (MainWindow)this.getRootPane().getParent();
		AbstractModelClass selected = this.getSelectedRecord();
		if(selected != null) {
			CD selectedCd = (CD)selected;
			mainWindow.getPanel_tracks().setCDDisplayed(selectedCd);
		} 
		else {
			mainWindow.getPanel_tracks().setCDDisplayed(null);
		}
	}

	private CD showCDDialog(CD cd) {
		
		CDEditDialog cded = new CDEditDialog();
		cded.setCD(cd);
		cded.setVisible(true);
		// control goes to dialog and returns
		CD rCd = cded.getCD();
		CD result = null;
		if(rCd == null)
			return null; // canceled
		if(rCd.getId() >= 0) { // update
			try {
				result = new CDController().update(cd, rCd);
			} catch (NullValueException e) {
				JOptionPane.showMessageDialog(this, e.getMessage(), "Update CD failed", JOptionPane.ERROR_MESSAGE);
			}
		}
		else { // create
			try {
				result = new CDController().create(rCd);
			} catch (NullValueException | RecordExistsException e) {
				JOptionPane.showMessageDialog(this, e.getMessage(), "Create CD failed", JOptionPane.ERROR_MESSAGE);
			}
		}
		super.refreshAllData();
		return result;
	}
}
