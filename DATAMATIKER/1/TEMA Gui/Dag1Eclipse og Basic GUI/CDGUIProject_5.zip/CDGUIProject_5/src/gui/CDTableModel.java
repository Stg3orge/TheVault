package gui;

import model.CD;
import util.PlayTime;

public class CDTableModel extends ATableModel {
	
	public CDTableModel() {
		super(new String[]{"Title", "Artists", "Play time" });
	}
	
	private CDTableModel(String[] columnNames) {
		super(columnNames);
	}

	@Override
	public String getValueAt(int row, int col) {
		if(super.getModelAt(row) == null)
			return null;
		CD cd = (CD)super.getModelAt(row);
		String result = null;
		switch (col) {
		case 0:
			result = cd.getTitle();
			break;
		case 1:
			if(cd.getArtists().size() > 0)
				result = cd.getArtists().get(0).getName();
			if(cd.getArtists().size() > 1)
				result += ", ...";
			break;
		case 2:
			result = PlayTime.formatDuration(cd.getPlayTime());
		}
		return result;
	}

}
