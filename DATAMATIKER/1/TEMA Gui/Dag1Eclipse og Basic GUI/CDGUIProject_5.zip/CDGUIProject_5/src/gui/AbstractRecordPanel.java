package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import model.AbstractModelClass;
import controller.AbstractRecordController;
import controller.MainController;
import exceptions.NullValueException;
import exceptions.RecordExistsException;
import javax.swing.ListSelectionModel;

public abstract class AbstractRecordPanel extends JPanel {
	private JTable table;
	
	public AbstractRecordPanel() {
		
		MainController.getInstance();
		
		setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane = new JScrollPane();
		add(scrollPane, BorderLayout.CENTER);
		
		table = new JTable();
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setModel(getTableModel()); // handcoded
		scrollPane.setViewportView(table);
		
		JPanel panel_buttons = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_buttons.getLayout();
		flowLayout.setAlignment(FlowLayout.RIGHT);
		add(panel_buttons, BorderLayout.SOUTH);
		
		JButton btnNew = new JButton("New");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actionNew();
			}
		});
		btnNew.setHorizontalAlignment(SwingConstants.RIGHT);
		panel_buttons.add(btnNew);
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actionEdit();
			}
		});
		panel_buttons.add(btnEdit);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actionDelete();
			}
		});
		panel_buttons.add(btnDelete);
		
		//finally, do subclass specific initialization
		doInit();
	}
	
	
	
	abstract void actionEdit();
	abstract void doInsertTestData() throws RecordExistsException, NullValueException;
	abstract void actionNew();
	abstract ATableModel getTableModel();
	@SuppressWarnings("rawtypes")
	abstract AbstractRecordController getRecordController();

	public AbstractRecordPanel(LayoutManager layout) {
		super(layout);
	}


	AbstractModelClass getSelectedRecord() {
		int selection = this.table.getSelectedRow();
		AbstractModelClass current = this.getTableModel().getModelAt(selection);
		return current;
	}
	
	protected void actionDelete() {
		AbstractModelClass current = getSelectedRecord();
		if(current == null)
			return;
		
		int choice = JOptionPane.showConfirmDialog(this, "Are you sure, you want to delete '" + current.getName() + "'?", "Delete " + getRecordController().getControlledModelName(), JOptionPane.YES_NO_OPTION);
		if(choice == JOptionPane.YES_OPTION) {
			try {
				this.getRecordController().delete(current.getId());
			} catch (NullValueException e) {
				JOptionPane.showMessageDialog(this, e.getMessage(), "Input error", JOptionPane.ERROR_MESSAGE);
			}
			//refreshData();
			refreshAllData();
			
		}
	}
	
	@SuppressWarnings("unchecked")
	void actionInsertTestData() {
		try {
			doInsertTestData();
		} catch (NullValueException e) {
			JOptionPane.showMessageDialog(this, e.getMessage(), "Input error", JOptionPane.ERROR_MESSAGE);
		} catch (RecordExistsException e) {
			JOptionPane.showMessageDialog(this, "Some test data already exist. Operation aborted.", "Data exists", JOptionPane.WARNING_MESSAGE);
		}
		refreshData();
	}

	abstract void doInit();

	protected JTable getTable() {
		return table;
	}
	
	protected void refreshData() {
		int sel = this.table.getSelectedRow();
		this.getTableModel().setModel(this.getModel());
		if (sel >= 0 && sel < this.table.getRowCount())
			this.table.setRowSelectionInterval(sel, sel);
	}
	
	protected void refreshAllData() {
		((MainWindow)(this.getRootPane().getParent())).refreshAllData();
	}
	
	/**
	 * Override to be more selective about what records to display.
	 * This default implementation shows all records that are associated to the panel's type.
	 */
	@SuppressWarnings("unchecked")
	protected <T extends AbstractModelClass> ArrayList<T> getModel() {
		return this.getRecordController().getAll();
	} 

}