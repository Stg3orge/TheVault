package gui;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.AbstractModelClass;
import model.CD;
import model.Track;
import controller.AbstractRecordController;
import controller.CDController;
import controller.Demo;
import controller.TrackController;
import exceptions.NullValueException;
import exceptions.RecordExistsException;

public class TrackPanel extends AbstractRecordPanel {
	public TrackPanel() {
	}
	private TrackTableModel tableModel;
	private CD displayedCdTracks = null;
	
	@Override
	void actionEdit() {
		Track track = (Track)super.getSelectedRecord();
		if(track == null) {
			JOptionPane.showMessageDialog(this, "Select a Track to edit!", "No Track selected", JOptionPane.WARNING_MESSAGE);
			return;	
		}
		showTrackDialog(track);
		//super.refreshData();
	}

	@Override
	void doInsertTestData() throws NullValueException, RecordExistsException {
		Demo.insertTrackDemoData();

	}

	@Override
	void actionNew() {
		showTrackDialog(null);
		super.refreshData();
	}

	@Override
	ATableModel getTableModel() {
		if(this.tableModel == null) {
			this.tableModel = new TrackTableModel();
		}
		return this.tableModel;
	}

	@SuppressWarnings("rawtypes")
	@Override
	AbstractRecordController getRecordController() {
		return new TrackController();
	}

	@Override
	void doInit(){}
	
	protected void setCDDisplayed(CD cd) {
		this.displayedCdTracks = cd;
		super.refreshData();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	protected  ArrayList<? extends AbstractModelClass> getModel() {
		if(this.displayedCdTracks == null)
			return null;
		
		try {
			TrackController tc = (TrackController)getRecordController();
			ArrayList<Track> tracks = tc.findAllOn(this.displayedCdTracks);
			return tracks;
		} catch (IllegalArgumentException | NullValueException e) {
			return null;
		} 
	}
	
	private Track showTrackDialog(Track track) {
		if (this.displayedCdTracks == null) {
			JOptionPane.showMessageDialog(this, "Select a CD to add a track to it!", "No CD selected", JOptionPane.WARNING_MESSAGE);
			return null;
		}
		
		TrackEditDialog trackEdit = new TrackEditDialog();
		trackEdit.setTrack(track);
		trackEdit.setVisible(true);
		
		// control goes to dialog and returns

		Track rTrack = trackEdit.getTrack();
		Track result = null;
		if(rTrack == null) { // cancelled
			return null; 
		}
		else {
			rTrack.setCD(this.displayedCdTracks);
			if(rTrack.getId() >= 0) { //update
				try {
					result = new TrackController().update(track, rTrack);
				} catch (NullValueException e) {
					JOptionPane.showMessageDialog(this, e.getMessage(), "Update Track failed", JOptionPane.ERROR_MESSAGE);
				}
			}
			else { // create 
				try {
					result = new TrackController().create(rTrack);
					this.displayedCdTracks.addTrack(result);
					new CDController().update(this.displayedCdTracks, this.displayedCdTracks);
					result = new TrackController().find(result.getId()); // updates all fields
				} catch (NullValueException | RecordExistsException e) {
					JOptionPane.showMessageDialog(this, e.getMessage(), "Create Track failed", JOptionPane.ERROR_MESSAGE);
				}
			}
			super.refreshAllData();
		}
		return result;
	}
	
	
}
