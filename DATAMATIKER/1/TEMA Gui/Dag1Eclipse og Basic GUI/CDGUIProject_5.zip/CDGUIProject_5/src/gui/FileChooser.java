package gui;

import java.awt.Component;
import java.io.File;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

public class FileChooser {
	private static JFileChooser chooser = new JFileChooser();
	private static File current = null;
	public static File show(Component parent) {
		chooser = new JFileChooser();
		chooser.setFileFilter(new FileFilter() {	
			@Override
			public String getDescription() {
				return "CD Archive (.cdx)";
			}
			
			@Override
			public boolean accept(File f) {
				if(f.getName().toLowerCase().endsWith(".cdx") || f.isDirectory())
					return true;
				return false;
			}
		});
		chooser.setSelectedFile(current);
	    int returnVal = chooser.showOpenDialog(parent);
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
	    	current = chooser.getSelectedFile();
	    	return chooser.getSelectedFile();
	    }
	    return null;
	}
}
