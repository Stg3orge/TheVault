package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import util.ArrayConvert;
import controller.ArtistController;
import model.Artist;
import model.CD;

public class CDEditDialog extends JDialog {

	private CD displayedCD;
	
	private final JPanel panelCD = new JPanel();
	private JTextField textCDTitle;
	private JList<Artist> listArtists; 


	/**
	 * Create the dialog.
	 */
	public CDEditDialog() {		
		setModal(true);
		setTitle("Create CD");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		panelCD.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(panelCD, BorderLayout.NORTH);
		panelCD.setLayout(new BorderLayout(0, 0));
		{
			JPanel panelCD_inner = new JPanel();
			panelCD.add(panelCD_inner, BorderLayout.NORTH);
			//panel.setPreferredSize(new Dimension(400,200));
			panelCD_inner.setLayout(new BorderLayout(0, 0));
			{
				JLabel lblCDTitle = new JLabel("CD Title:   ");
				panelCD_inner.add(lblCDTitle, BorderLayout.WEST);
			}
			
			textCDTitle = new JTextField();
			panelCD_inner.add(textCDTitle, BorderLayout.CENTER);
			//textCDTitle.setColumns(40);
		}
		{
			JPanel panelArtists = new JPanel();
			panelArtists.setBorder(new TitledBorder(null, "Artists", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			getContentPane().add(panelArtists, BorderLayout.CENTER);
			panelArtists.setLayout(new BorderLayout(0, 0));
			{
				JScrollPane scrollPaneArtists = new JScrollPane();
				panelArtists.add(scrollPaneArtists);
				{
					listArtists = new JList<Artist>();
					scrollPaneArtists.setViewportView(listArtists);
				}
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if(displayedCD == null)
							displayedCD = new CD();
						setVisible(false);
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		
		// Populate Artist list!
		populateArtistListModel();
	}
	
	private void populateArtistListModel() {
		ArrayList<Artist> allArtists = new ArtistController().getAll();
		DefaultListModel<Artist> artistListModel = new DefaultListModel<Artist>();
		for(int i = 0 ; i < allArtists.size(); i++) {
			artistListModel.addElement(allArtists.get(i));
		}
		this.listArtists.setModel(artistListModel);
	} 
	
	public void setCD(CD cd) {
		this.displayedCD = cd;
		if(cd != null) {
			this.setTitle("Edit CD");
			this.textCDTitle.setText(cd.getTitle());
		
			// select artists
			ArrayList<Integer> indexList = new ArrayList<>(cd.getArtists().size());
			for(int i = 0; i < listArtists.getModel().getSize(); i++) {
				for(Artist artist : cd.getArtists()) {
					if(artist.equals(listArtists.getModel().getElementAt(i))) {
						indexList.add(i);
					}
				}
			}

			int[] indices = ArrayConvert.toIntArray(indexList);
			this.populateArtistListModel();
			this.listArtists.setSelectedIndices(indices);
		}
	}
	
	public CD getCD() {
		if(this.displayedCD == null)
			return null;
		
		this.displayedCD.setTitle(this.textCDTitle.getText().trim());
		List<Artist> artists = this.listArtists.getSelectedValuesList();
		this.displayedCD.getArtists().clear();
		for(int i = 0 ; i < artists.size(); i++) {
			this.displayedCD.addArtist(artists.get(i));
		}
		
		return this.displayedCD;
	}
}
