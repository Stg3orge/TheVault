package gui;


public class ArtistTableModel extends ATableModel {
	public ArtistTableModel () {
		super(new String[]{"Name"});
	}

	@Override
	public String getValueAt(int row, int col){
		if(this.getModelAt(row) == null)
			return null;
		return super.getModelAt(row).getName();
	}

}
