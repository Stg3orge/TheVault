package model;

import java.util.ArrayList;

import util.PlayTime;

public class CD extends AbstractModelClass {
	private static final long serialVersionUID = 1L;
	
	private String title;
	private int year;
	
	public CD() {
		super();
	
	}
	
	protected CD(int id) {
		super(id);
		
	}
	
	
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	private final ArrayList<Artist> artists = new ArrayList<Artist>(4);
	private final ArrayList<Track> tracks = new ArrayList<Track>();
	
	@Override
	public AbstractModelClass clone() {
		CD cd = new CD(this.getId());
		cd.setTitle(this.title);
		cd.setYear(this.year);
		for(Artist artist : artists) {
			cd.addArtist(artist.clone());
		}
		for(Track track : tracks ) {
			cd.addTrack(track.clone());
		}
		return cd;
	}
	
	@Override
	public AbstractModelClass deepClone() {
		CD cd = new CD(this.getId());
		cd.setTitle(this.title);
		cd.setYear(this.year);
		for(int i = 0 ; i < artists.size(); i++ ) {
			cd.addArtist(artists.get(i).deepClone());
		}
		for(int i = 0 ; i < tracks.size() ; i++ ) {
			cd.addTrack(tracks.get(i).deepClone());
		}
		return cd;
	}

	@Override
	public int hashCode() {
		return this.getId();
	}

	@Override
	public String getName() {
		return getTitle();
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}
	
	public int getPlayTime() {
		int result = 0;
		for(Track track : this.tracks)
			result += track.getPlayTime();
		return result;
	}
	
	public ArrayList<Artist> getArtists() {
		return this.artists;
	}
	
	public void addArtist(Artist artist) {
		this.artists.add(artist);
	}
	
	public ArrayList<Track> getTracks() {
		return this.tracks;
	}
	
	public void addTrack(Track track) {
		track.setCD(this);
		this.tracks.add(track);
	}
	
	public Track removeTrack(Track track) {
		for(Track t : this.tracks) {
			if(t.equals(track)) {
				tracks.remove(t);
				t.setCD(null);
				return t;
			}
		} 
		return null;
	}
	
	@Override
	public String toString() {
		String result = super.toString() + " year: " + this.year + " (" + PlayTime.formatDuration(this.getPlayTime()) + ")\n    artists:\n";
		for(int i = 0; i< this.artists.size(); i++)
			result+="        " + this.artists.get(i).toString() + "\n";
		result += "    tracks:\n" ;
		for(int i = 0 ; i < this.tracks.size(); i++) 
			result += "        " + this.tracks.get(i).toString() + "\n";
			
		return result;
	}

	public boolean removeArtist(Artist deleted) {
		return this.artists.remove(deleted);
	}
}
