package model;

import java.io.Serializable;

/**
 * Usage example: public class Artist extends AbstractModelClass<Artist> { ... (class definition) ... }
 *
 * @param <Self>
 */
public abstract class AbstractModelClass implements Serializable{
	private static final long serialVersionUID = 1L;

	private int id;

	protected AbstractModelClass(int id) {
		this.id = id;
	}
	
	public AbstractModelClass() {
		this.id = -1;
	}
	
	public int getId() {
		return this.id;
	}
	
	@Override
	public abstract AbstractModelClass clone();
	public abstract AbstractModelClass deepClone();
	
	protected void setId(int id) {
		this.id = id;
	}
	
	@Override
	public abstract int hashCode() ;

	public boolean equals(Object o) {
		try {
			return ((AbstractModelClass)o).getId() == this.id;
		} catch (Exception e) {
			return false;
		}
	}
	
	public abstract String getName();
	
	@Override
	public String toString() {
		String s =  this.getClass().getSimpleName() + ": " + this.getId() + " " + this.getName();
		return s;
	}
}
