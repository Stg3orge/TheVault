package model;


public class CDContainer extends AbstractContainer<CD> {
	private static final long serialVersionUID = 1L;
	
	private static CDContainer instance;
	
	private CDContainer() {
		super();
	}
	
	public static CDContainer getInstance() {
		if(instance == null)
			instance = new CDContainer();
		return instance;
	}
	
	
	@Override
	public String getRecordName() {
		return "CD";
	}
	
	public static void setInstance(CDContainer containerInstance) {
		instance = containerInstance;
	}
}
