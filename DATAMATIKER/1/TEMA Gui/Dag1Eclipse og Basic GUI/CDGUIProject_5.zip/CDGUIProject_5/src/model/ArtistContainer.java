package model;


public class ArtistContainer extends AbstractContainer<Artist> {
	private static final long serialVersionUID = 1L;
	
	//private static AbstractContainer<Artist> instance;
	private static ArtistContainer instance;
	
	public static AbstractContainer<Artist> getInstance() {
		if(instance == null)
			instance = new ArtistContainer();
		return instance;
	}
	
	private ArtistContainer() {
		super();
	}


	@Override
	public String getRecordName() {
		return "Artist";
	}

	public static void setInstance(ArtistContainer containerInstance) {
		instance = containerInstance;
	}
	
}
