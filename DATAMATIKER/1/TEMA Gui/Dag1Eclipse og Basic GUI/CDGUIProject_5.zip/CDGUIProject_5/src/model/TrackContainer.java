package model;

public class TrackContainer extends AbstractContainer<Track>{
	private static final long serialVersionUID = 1L;
	
	private static TrackContainer instance;
	
	public static TrackContainer getInstance() {
		if(instance == null)
			instance = new TrackContainer();
		return instance;
	}
	
	private TrackContainer() {
		super();
	}
	@Override
	public String getRecordName() {
		return "Track";
	}
	
	public static void setInstance(TrackContainer containerInstance) {
		instance = containerInstance;
	}

}
