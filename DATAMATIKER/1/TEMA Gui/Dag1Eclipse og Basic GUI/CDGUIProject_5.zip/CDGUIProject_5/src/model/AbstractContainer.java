package model;

import java.io.Serializable;
import java.util.ArrayList;

import exceptions.NullValueException;
import exceptions.RecordExistsException;

public abstract class AbstractContainer<T extends AbstractModelClass> implements Serializable {
	private static final long serialVersionUID = 1L;
	

	private ArrayList<T> elements = new ArrayList<T>();
	private int idPointer;
	
	public abstract String getRecordName();
	
	protected int nextId() {
		return idPointer++;
	}
	
	
	public T find(int id) throws IllegalArgumentException, NullValueException {
		if(id < 0 || id >= this.idPointer)
			throw new NullValueException("ID");
		
		for(T t : elements) {
			if(t.getId() == id) {
				return t;
			}
		}
		return null;
	}
	
	/**
	 * 
	 * @param t
	 * @return Model instance that <code>equals</code> the passed object. ID is ignored.
	 * @throws NullValueException
	 */
	public T find (T t) throws NullValueException {
		if(t==null){
			throw new NullValueException(getRecordName());
		} 
		for(T tt : elements) {
			if(tt.equals(t))
				return tt;
		}
		return null;
	}

	public ArrayList<T> searchName(String substring) throws NullValueException {
		if(substring == null || substring.trim().equals("")) 
			throw new NullValueException("search term");
		
		ArrayList<T> results = new ArrayList<T>();
		for(T t : elements) {
			if(t.getName().toLowerCase().indexOf(substring.trim().toLowerCase()) > -1){
				results.add(t);
			}
		}
		return results;
	}

	public T delete(int id) throws NullValueException {
		T t = find(id);
		if(elements.remove(t))
			return t;
		return null;
	}

	public ArrayList<T> getAll() {
		return this.elements;
	}
	
	public void add(T t) throws NullValueException, RecordExistsException {
		if(t == null)
			throw new NullValueException(getRecordName());
		if(find(t) != null || t.getId() > -1 && find(t.getId()) != null)
			throw new RecordExistsException(getRecordName(), t.getName());
		t.setId(this.nextId());
		this.elements.add(t);
	}

}