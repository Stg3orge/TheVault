package model;

public class Artist extends AbstractModelClass {
	private static final long serialVersionUID = 1L;
	
	private String name;
	
	protected Artist(int id) {
		super(id);
	}
	
	public Artist() {
		super();
	}
	
	@Override
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	
	@Override
	public Artist clone() {
		Artist clone = new Artist(this.getId());
		clone.setName(this.name);
		return clone;
	}

	@Override
	public Artist deepClone() {
		return clone();
	}
	
	
}
