package model;

import util.PlayTime;

public class Track extends AbstractModelClass {
	private static final long serialVersionUID = 1L;

	private String name;
	private int playTime;
	private CD cd;
	
	public Track() {
		super();
	}
	
	protected Track(int id) {
		super(id);
	}
	
	@Override
	public Track clone() {
		Track track = new Track(this.getId());
		track.setName(this.name);
		track.setPlayTime(this.playTime);
		track.setCD(this.cd);
		return track;
	}
	
	@Override
	public Track deepClone() {
		Track track = clone();
		if(this.cd != null) {
			CD cd = new CD(this.cd.getId());
			track.setCD(cd);
		}
		return track;
	}

	public CD getCD() {
		return cd;
	}

	public void setCD(CD cd) {
		this.cd = cd;
	}

	@Override
	public int hashCode() {
		return getId();
	}

	@Override
	public String getName() {
		return this.name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getPlayTime() {
		return this.playTime;
	}
	
	public void setPlayTime(int seconds) {
		this.playTime = seconds;
	}
	
	@Override
	public String toString() {
		return super.toString() + " (" + PlayTime.formatDuration(this.playTime) + "), CD: " + (this.cd != null ? "" + this.cd.getId() + " " + this.cd.getName() : " - ");
	}

}
