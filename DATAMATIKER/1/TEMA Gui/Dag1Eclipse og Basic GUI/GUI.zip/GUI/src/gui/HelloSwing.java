package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class HelloSwing extends JFrame {
	
	private JPanel contentPane;
	private JLabel lblMessage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HelloSwing frame = new HelloSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public HelloSwing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		super.setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblMessage = new JLabel("");
		lblMessage.setBounds(48, 69, 320, 16);
		contentPane.add(lblMessage);
		
		JButton btnClickMe = new JButton("Click Me!");
		btnClickMe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btnClickMeClicked();
			}
		});
		btnClickMe.setBounds(151, 111, 97, 25);
		contentPane.add(btnClickMe);
	}

	private void btnClickMeClicked() {
		//System.out.println("click!");
		lblMessage.setText("Hello, Swing!");
	}
}
