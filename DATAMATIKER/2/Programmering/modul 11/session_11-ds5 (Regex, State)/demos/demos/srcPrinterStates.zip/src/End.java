
public class End extends State {

	public End() {
		super();
	}

	@Override
	public void action() {
		System.out.println("End printing...");
	}

}
