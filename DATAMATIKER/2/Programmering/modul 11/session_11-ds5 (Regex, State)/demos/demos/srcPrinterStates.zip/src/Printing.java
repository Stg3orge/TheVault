
public class Printing extends State {

	public Printing() {
		super();
	}

	@Override
	public void action() {
        System.out.println("Printing...");
        //do all the printing work
	}

}
