/** 
  * @author (FEN)
  * @version (2015-03-17)
  */
public class Start extends State {

	public Start() {
		super();
	}

	@Override
	public void action() {
        System.out.println("Printer starting");
        //Whatever is need to initializing the printer
	}

}
