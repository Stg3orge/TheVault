
public class Error extends State {

	public Error() {
		super();
	}

	@Override
	public void action() {
		System.out.println("Paper jam! Call for help!");

	}

}
