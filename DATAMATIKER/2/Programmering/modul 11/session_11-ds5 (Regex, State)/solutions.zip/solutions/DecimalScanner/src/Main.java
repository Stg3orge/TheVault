/** 
 * Testing integer scanner
 * 
 * @author (FEN)
 * @version (2015-03-15)
 */

class Main
{
    public static void main(String[] args)
    {
        Scanner intScan = new Scanner();
        System.out.println(intScan.scan("-11,133"));
    }
}
