
public interface DoSomething {
	int doIt(int a, int b, int c);
}
