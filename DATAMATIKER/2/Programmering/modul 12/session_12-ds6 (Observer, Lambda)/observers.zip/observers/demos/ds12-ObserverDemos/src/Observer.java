/**
 * 
 */

/**
 * @author fen
 *
 */
public interface Observer {

    public void notifyMe(int amount);
}
