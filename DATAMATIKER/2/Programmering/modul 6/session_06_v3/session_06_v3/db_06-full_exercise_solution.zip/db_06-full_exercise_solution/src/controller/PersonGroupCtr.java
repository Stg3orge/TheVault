package controller;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

import db.HorribleException;
import model.Group;
import model.Person;

public class PersonGroupCtr implements PersonGroupCtrIF {
	private Person p;
	private PersonCtrIF pCtr;
	private GroupCtrIF gCtr;
	
	public PersonGroupCtr() throws HorribleException {
		pCtr = new PersonCtr();
		gCtr = new GroupCtr();
	}
	
	/* (non-Javadoc)
	 * @see controller.PersonGroupCtrIF#showPersons()
	 */
	@Override
	public List<Person> showPersons() throws HorribleException {
		return new PersonCtr().findAll();
	}
	
	/* (non-Javadoc)
	 * @see controller.PersonGroupCtrIF#pickPerson(int)
	 */
	@Override
	public Person pickPerson(int id) throws HorribleException {
		p = pCtr.findById(id);
		return p;
	}
	
	/* (non-Javadoc)
	 * @see controller.PersonGroupCtrIF#showGroups()
	 */
	@Override
	public List<Group> showGroups() throws HorribleException {
		return gCtr.findAll();
	}
	
	/* (non-Javadoc)
	 * @see controller.PersonGroupCtrIF#pickNewGroup(int)
	 */
	@Override
	public void pickNewGroup(int gid) throws HorribleException {
		pCtr.updatePerson(p.getId(), p.getName(), 
				p.getEmail(), p.getPhone(), 
				p.getBirthDate(), gid);
	}
}
