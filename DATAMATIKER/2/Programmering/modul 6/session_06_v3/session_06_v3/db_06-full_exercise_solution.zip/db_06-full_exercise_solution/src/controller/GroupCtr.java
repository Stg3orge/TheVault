package controller;

import java.sql.SQLException;
import java.util.List;

import db.GroupDB;
import db.GroupDBIF;
import db.HorribleException;
import model.Group;

public class GroupCtr implements GroupCtrIF {
	private GroupDBIF groupdDB;
	
	public GroupCtr() throws HorribleException  {
		try {
			groupdDB = new GroupDB();
		} catch (SQLException e) {
			throw new HorribleException(e, "Can't create GroupDB");
		}
	}
	/* (non-Javadoc)
	 * @see controller.GroupCtrIF#findAll()
	 */
	@Override
	public List<Group> findAll() throws HorribleException {
		return groupdDB.findAll();
	}
	/* (non-Javadoc)
	 * @see controller.GroupCtrIF#findById(int)
	 */
	@Override
	public Group findById(int id) throws HorribleException {
		return groupdDB.findById(id);
	}

}
