package controller;

import java.time.LocalDate;
import java.util.List;

import db.HorribleException;
import db.PersonDB;
import db.PersonDBIF;
import model.Person;

public class PersonCtr implements PersonCtrIF {
	private PersonDBIF personDB;

	public PersonCtr() throws HorribleException {
		this.personDB = new PersonDB();
	}
	/* (non-Javadoc)
	 * @see controller.PersonCtrIF#findAll()
	 */
	@Override
	public List<Person> findAll() throws HorribleException {
		return personDB.findAll();
	}
	
	/* (non-Javadoc)
	 * @see controller.PersonCtrIF#findById(int)
	 */
	@Override
	public Person findById(int id) throws HorribleException {
		return personDB.findById(id);
	}
	
	/* (non-Javadoc)
	 * @see controller.PersonCtrIF#updatePerson(int, java.lang.String, java.lang.String, java.lang.String, java.time.LocalDate, int)
	 */
	@Override
	public void updatePerson (int id, String name, String email, String phone, LocalDate birthDate, int groupId) throws HorribleException {
		personDB.update(id, name, email, phone, birthDate, groupId);
	}
}
