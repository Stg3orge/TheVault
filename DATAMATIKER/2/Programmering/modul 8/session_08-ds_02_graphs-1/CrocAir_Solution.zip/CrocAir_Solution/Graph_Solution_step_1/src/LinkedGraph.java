import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.TreeMap;

public class LinkedGraph implements GraphIF  {
	
	public LinkedGraph(int initSize) {
	}

	@Override
	public void addVertex(Vertex v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getVertexCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getEdgeCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean containsVertex(Vertex v) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void addEdge(Vertex from, Vertex to) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isAdjacent(Vertex from, Vertex to) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Vertex> getAdjacencies(Vertex v) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void unMarkAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void markAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dfs(Vertex v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bfs(Vertex v) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
}