use master;
if exists(select * from sys.databases where name = 'CUSTOMTYPES')
	drop database customtypes;

create database customTypes;
go

use customTypes;

create type xyz from varchar(10);
go

create table mytable ( property xyz not null);

insert into mytable values ('joe');
-- insert into mytable values ('joejoejoejoejoejoejoejoejoe');