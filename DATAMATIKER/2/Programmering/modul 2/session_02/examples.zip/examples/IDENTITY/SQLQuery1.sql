--create database mytest;
--go

use mytest;
if object_id('dbo.people') is not null
	drop table dbo.people;

use mytest;

create table people (
	id int primary key identity (1,1),
	name varchar(50) not null UNIQUE
)