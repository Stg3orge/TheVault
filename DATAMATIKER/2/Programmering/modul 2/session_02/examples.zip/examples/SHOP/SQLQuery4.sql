use master;

if exists(select * from sys.databases where name='shop')
	drop database shop;
go

CREATE database shop;
go

use shop;

-- dropping individual tables IN a database
--if object_id('dbo.products') is not null
--	drop table dbo.products;

create table products (
	id int primary key identity (1,1),
	name varchar(50) not null unique,
	price decimal(10,2) check(price >= 0) not null
)
create table orders (
	id int primary key identity (1,1),
	customer_name varchar(50),
	delivery_address varchar(50)
)
create table order_lines (
	products_id int,
	orders_id int,
	quantity int not null check(quantity > 0),
	primary key(products_id, orders_id),
	constraint products_id_FK foreign key(products_id) references products(id),
	constraint orders_id_FK foreign key(orders_id) references orders(id)
)

-- dropping a constraint - may be needed to drop tables successfully
--alter table order_lines drop constraint products_id_FK;

insert into products values('Banana', 10.2);
insert into products values('Boat', 100.5);
insert into products values('Boots', 25.0);

insert into orders (customer_name, delivery_address) values ('Joe', 'Tropical Island');
insert into orders values ('Jane', 'City by the Jungle');

		


insert into order_lines (orders_id, products_id, quantity) values (1, 2, 1);
insert into order_lines (orders_id, products_id, quantity) values
	(
		(select id from orders where customer_name = 'joe'),
		(select id from products where name = 'boots'),
		2
	);
insert into order_lines (orders_id, products_id, quantity) values (
		(select id from orders where customer_name = 'jane'),
		(select id from products where name like 'banana'),
		100
	);

-- test
select customer_name, products.name as product_name, (quantity * products.price) as subtotal 
from orders, products, order_lines 
where orders.id = order_lines.orders_id and order_lines.products_id = products.id;

select customer_name, sum(quantity * products.price) as total 
from orders, products, order_lines 
where orders.id = order_lines.orders_id and order_lines.products_id = products.id 
	group by customer_name;