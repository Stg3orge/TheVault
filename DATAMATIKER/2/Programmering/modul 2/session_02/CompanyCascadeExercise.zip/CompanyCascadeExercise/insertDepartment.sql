



insert into department values('Research', 5, '333445555','19880522');
insert into department values('Administration',4,'987654321','19950101');
insert into department values('Headquarters',1,'888665555','19810619');