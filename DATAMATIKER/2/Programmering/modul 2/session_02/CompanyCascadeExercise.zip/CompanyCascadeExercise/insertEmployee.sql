

insert into employee values ('James','E','Borg','888665555','19371110','450 Stone, Houston,TX','M',55000,null,1);

insert into employee values ('Franklin','T', 'Wong','333445555','19551208','638 Voss, Houston, TX','M',40000,'888665555',5);
insert into employee values ('Jennifer','S','Wallace','987654321','19410620','291,Berry, Belaire,TX','F',43000,'888665555',4);
insert into employee values ('Alicia','J','Zelaya','999887777','19680119','3321 Castle, Spring,TC','F',25000,'987654321',4);
insert into employee values ('Ramesh','K','Narayalan','666884444','19620915','975, Fire Oak, Humble, TX','M',38000,'333445555',5);
insert into employee values ('John','B','Smith','123456789','19650109','731 Fondren, Houston,TX','M',30000,'333445555',5);
insert into employee values ('Joyce','A','English','453453453','19720731','5631Rice Houston,TX','F',25000,'333445555',5);
insert into employee values ('Ahmad','V','Jabbar','987987987','19690329','980 Dallas Houston, TX','M',25000,'987654321',4);
