select * from department;
select * from employee;
select * from dept_locations;
select * from Project;
select * from Works_on;
select * from Dependent;
delete from Employee
	where ssn = '123456789';

select * from department;
select * from employee;
select * from dept_locations;
select * from Project;
select * from Works_on;
select * from Dependent;