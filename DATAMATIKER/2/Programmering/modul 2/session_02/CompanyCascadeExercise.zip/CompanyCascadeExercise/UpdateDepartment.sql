select * from department;
select * from employee;
select * from dept_locations;
select * from Project;
select * from Works_on;
select * from Dependent;
update department
  set dnumber = 7
  where dnumber = 1;
select * from department;
select * from employee;
select * from dept_locations;
select * from Project;
select * from Works_on;
select * from Dependent;