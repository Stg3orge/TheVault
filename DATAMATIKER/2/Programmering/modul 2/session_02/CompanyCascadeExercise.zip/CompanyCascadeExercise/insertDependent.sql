
insert into dependent values('333445555','Alice','F','19860405','Daugther');
insert into dependent values('333445555','Theodore','M','19831025','Son');
insert into dependent values('333445555','Joy','F','19580503','Spouse');

insert into dependent values('987654321','Abner','M','19420228','Spouse');

insert into dependent values('123456789','Michael','M','19880104','Son');
insert into dependent values('123456789','Alice','F','19881230','Daugther');
insert into dependent values('123456789','Elizabeth','F','19670505','Spouse');