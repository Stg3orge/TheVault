
insert into dept_locations values(1,'Houston');
insert into dept_locations values(4,'Stafford');
insert into dept_locations values (5,'Bellaire');
insert into dept_locations values (5,'Sugarland');
insert into dept_locations values (5,'Houston');