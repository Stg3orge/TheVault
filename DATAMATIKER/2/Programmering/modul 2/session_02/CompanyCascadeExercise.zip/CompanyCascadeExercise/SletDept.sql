select * from department;
select * from employee;
select * from dept_locations;
select * from Project;
delete from department
  where dnumber = 4;
select * from department;
select * from employee;
select * from dept_locations;
select * from Project;