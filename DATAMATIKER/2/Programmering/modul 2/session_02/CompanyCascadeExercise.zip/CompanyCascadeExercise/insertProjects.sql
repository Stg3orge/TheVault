

insert into project values ('ProductX',1,'Bellaire',5);
insert into project values ('ProductY',2,'Sugarland',5);
insert into project values ('ProductZ',3,'Houston',5);
insert into project values ('Computerzation',10,'Stafford',4);
insert into project values ('Reorganization',20,'Houston',1);
insert into project values ('Newbenefits',30,'Stafford',4);
