use OtherCompany;

select *
from Employee
where dno <> 5
