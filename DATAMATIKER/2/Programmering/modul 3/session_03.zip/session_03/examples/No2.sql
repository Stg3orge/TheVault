use OtherCompany;

select fname + ' ' + lname as fullName
from Employee