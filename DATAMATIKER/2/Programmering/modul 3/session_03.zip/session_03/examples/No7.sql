use OtherCompany;

select *
from employee
where fname like 'j%'

select *
from employee
where fname not like 'j%'